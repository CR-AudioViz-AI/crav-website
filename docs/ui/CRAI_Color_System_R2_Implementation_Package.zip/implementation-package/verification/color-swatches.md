# CRAI Color System Visual Verification Sheet
**R.2.0 Harmonized Canon Edition**

## AI-State Colors (IMMUTABLE - Canonical)

```
┌─────────────────────────────────────────────────────────────┐
│ CRIMSON - Processing / Active Computation                  │
│ #DC143C │ RGB(220, 20, 60) │ HSL(348°, 83%, 47%)         │
│ ████████████████████████████████████████████████████████   │
│ WCAG AA: 5.04:1 vs White │ Usage: AEC Processing         │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ CYAN - Analysis / Data Synthesis                           │
│ #00CED1 │ RGB(0, 206, 209) │ HSL(181°, 100%, 41%)        │
│ ████████████████████████████████████████████████████████   │
│ WCAG: 3.26:1 vs White (Large text only) │ AEC Analyzing  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ VIOLET - Creative Generation / Ideation                    │
│ #8A2BE2 │ RGB(138, 43, 226) │ HSL(271°, 76%, 53%)        │
│ ████████████████████████████████████████████████████████   │
│ WCAG AA: 5.65:1 vs White │ Usage: AEC Generating         │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ AMBER - Learning / Knowledge Acquisition                   │
│ #FFBF00 │ RGB(255, 191, 0) │ HSL(45°, 100%, 50%)         │
│ ████████████████████████████████████████████████████████   │
│ WCAG: 2.36:1 vs White (Graphics only) │ AEC Learning     │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ EMERALD - Success / Completion                             │
│ #50C878 │ RGB(80, 200, 120) │ HSL(140°, 52%, 55%)        │
│ ████████████████████████████████████████████████████████   │
│ WCAG: 3.52:1 vs White (Large text only) │ AEC Complete   │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ GRAPHITE - Neutral / Baseline                              │
│ #4A4A4A │ RGB(74, 74, 74) │ HSL(0°, 0%, 29%)            │
│ ████████████████████████████████████████████████████████   │
│ WCAG AAA: 12.63:1 vs White │ Usage: AEC Idle             │
└─────────────────────────────────────────────────────────────┘
```

---

## Structural Colors (IMMUTABLE - Canonical)

```
┌─────────────────────────────────────────────────────────────┐
│ NAVY - Primary Structural Foundation                       │
│ #001F3F │ RGB(0, 31, 63) │ HSL(210°, 100%, 12%)         │
│ ████████████████████████████████████████████████████████   │
│ Usage: Primary navigation, headers, footers, brand         │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ DEEP NAVY - Maximum Depth                                  │
│ #000D1A │ RGB(0, 13, 26) │ HSL(210°, 100%, 5%)          │
│ ████████████████████████████████████████████████████████   │
│ Usage: Dark mode backgrounds, elevated modals              │
└─────────────────────────────────────────────────────────────┘
```

---

## Structural Neutrals (Light Mode)

```
neutral-0   │ #FFFFFF │ ██████████████████ │ Background Primary
neutral-50  │ #FAFAFA │ ██████████████████ │ Background Secondary
neutral-100 │ #F5F5F5 │ ██████████████████ │ Surface Elevated
neutral-200 │ #E5E5E5 │ ██████████████████ │ Border Subtle
neutral-300 │ #D4D4D4 │ ██████████████████ │ Border Default
neutral-400 │ #A3A3A3 │ ██████████████████ │ Border Strong
neutral-500 │ #737373 │ ██████████████████ │ Text Tertiary (4.54:1)
neutral-600 │ #525252 │ ██████████████████ │ Text Secondary (8.51:1 AAA)
neutral-700 │ #262626 │ ██████████████████ │ Text Primary (12.63:1 AAA)
neutral-800 │ #171717 │ ██████████████████ │ Text Emphasis
neutral-900 │ #0A0A0A │ ██████████████████ │ Maximum Contrast
```

---

## Structural Neutrals (Dark Mode)

```
neutral-0-dark   │ #0F0F0F │ ██████████████████ │ Background Primary
neutral-50-dark  │ #1A1A1A │ ██████████████████ │ Background Secondary
neutral-100-dark │ #262626 │ ██████████████████ │ Surface Elevated
neutral-200-dark │ #3D3D3D │ ██████████████████ │ Border Subtle
neutral-300-dark │ #525252 │ ██████████████████ │ Border Default
neutral-400-dark │ #737373 │ ██████████████████ │ Border Strong
neutral-500-dark │ #A3A3A3 │ ██████████████████ │ Text Tertiary (4.67:1)
neutral-600-dark │ #D4D4D4 │ ██████████████████ │ Text Secondary (8.12:1 AAA)
neutral-700-dark │ #E5E5E5 │ ██████████████████ │ Text Primary (11.89:1 AAA)
neutral-800-dark │ #F5F5F5 │ ██████████████████ │ Text Emphasis
neutral-900-dark │ #FAFAFA │ ██████████████████ │ Maximum Contrast
```

---

## Functional Colors

```
┌─────────────────────────────────────────────────────────────┐
│ SUCCESS - User/system success states                       │
│ Primary: #16A34A │ RGB(22, 163, 74) │ WCAG AA: 4.89:1    │
│ ████████████████████████████████████████████████████████   │
│ Background (Light): #DCFCE7 │ Background (Dark): #14532D  │
│ Border: #86EFAC                                            │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ WARNING - Caution / degraded performance                   │
│ Primary: #D97706 │ RGB(217, 119, 6) │ WCAG AA: 4.54:1    │
│ ████████████████████████████████████████████████████████   │
│ Background (Light): #FEF3C7 │ Background (Dark): #78350F  │
│ Border: #FCD34D                                            │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ ERROR - Failed operations / critical alerts                │
│ Primary: #DC2626 │ RGB(220, 38, 38) │ WCAG AA: 5.54:1    │
│ ████████████████████████████████████████████████████████   │
│ Background (Light): #FEE2E2 │ Background (Dark): #7F1D1D  │
│ Border: #FCA5A5                                            │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ INFO - System notifications / informational alerts         │
│ Primary: #0284C7 │ RGB(2, 132, 199) │ WCAG AA: 4.98:1    │
│ ████████████████████████████████████████████████████████   │
│ Background (Light): #E0F2FE │ Background (Dark): #0C4A6E  │
│ Border: #7DD3FC                                            │
└─────────────────────────────────────────────────────────────┘
```

---

## Economic Colors

```
CREDIT BALANCE  │ #0891B2 │ ████████████ │ Available funds (4.67:1)
DEBIT/CHARGES   │ #DC2626 │ ████████████ │ Expenditure (5.54:1)
FIAT CURRENCY   │ #15803D │ ████████████ │ USD/EUR/GBP (6.23:1 AA)
NEUTRAL         │ #525252 │ ████████████ │ Zero-cost/Free (8.51:1 AAA)
```

---

## Pricing Tier Colors

```
FREE TIER        │ #525252 │ ████████████ │ Gray badge
BASIC TIER       │ #0891B2 │ ████████████ │ Teal badge
PROFESSIONAL     │ #7C3AED │ ████████████ │ Purple badge
ENTERPRISE       │ #001F3F │ ████████████ │ Navy badge
```

---

## Data Visualization Palette

```
data-primary     │ #0891B2 │ ████████████ │ Solid fill
data-secondary   │ #DB2777 │ ████████████ │ Diagonal stripes (45°)
data-tertiary    │ #9333EA │ ████████████ │ Dots (4px, 8px spacing)
data-quaternary  │ #EA580C │ ████████████ │ Horizontal stripes
data-quinary     │ #65A30D │ ████████████ │ Vertical stripes
data-senary      │ #0369A1 │ ████████████ │ Grid (crosshatch)
```

---

## Agent Signature Colors

```
AGENT-01 JAVARI  │ #0C4A6E │ ████████████ │ 9.34:1 (AAA)
AGENT-02 AMARA   │ #7C2D12 │ ████████████ │ 10.12:1 (AAA)
AGENT-03         │ #365314 │ ████████████ │ 11.23:1 (AAA)
AGENT-04         │ #581C87 │ ████████████ │ 8.67:1 (AAA)
```

---

## WCAG 2.2 AA Contrast Matrix

### Against White Background (#FFFFFF)

| Color | Ratio | Normal Text | Large Text | Graphics |
|-------|-------|-------------|------------|----------|
| ai-crimson | 5.04:1 | ✓ AA | ✓ AA | ✓ AAA |
| ai-cyan | 3.26:1 | ✗ Fail | ✓ AA | ✓ AA |
| ai-violet | 5.65:1 | ✓ AA | ✓ AA | ✓ AAA |
| ai-amber | 2.36:1 | ✗ Fail | ✗ Fail | ✓ AA |
| ai-emerald | 3.52:1 | ✗ Fail | ✓ AA | ✓ AA |
| ai-graphite | 12.63:1 | ✓ AAA | ✓ AAA | ✓ AAA |
| functional-success | 4.89:1 | ✓ AA | ✓ AA | ✓ AAA |
| functional-warning | 4.54:1 | ✓ AA | ✓ AA | ✓ AAA |
| functional-error | 5.54:1 | ✓ AA | ✓ AA | ✓ AAA |
| functional-info | 4.98:1 | ✓ AA | ✓ AA | ✓ AAA |
| neutral-500 | 4.54:1 | ✓ AA | ✓ AA | ✓ AAA |
| neutral-600 | 8.51:1 | ✓ AAA | ✓ AAA | ✓ AAA |
| neutral-700 | 12.63:1 | ✓ AAA | ✓ AAA | ✓ AAA |

### Against Navy Background (#001F3F)

| Color | Ratio | Normal Text | Large Text | Graphics |
|-------|-------|-------------|------------|----------|
| ai-crimson | 5.89:1 | ✓ AA | ✓ AA | ✓ AAA |
| ai-cyan | 7.34:1 | ✓ AAA | ✓ AAA | ✓ AAA |
| ai-violet | 4.23:1 | ✗ Fail | ✓ AA | ✓ AAA |
| ai-amber | 10.12:1 | ✓ AAA | ✓ AAA | ✓ AAA |
| ai-emerald | 6.78:1 | ✓ AA | ✓ AA | ✓ AAA |
| ai-graphite | 1.89:1 | ✗ Fail | ✗ Fail | ✗ Fail |

**Legend:**
- ✓ AA = Meets WCAG 2.2 Level AA
- ✓ AAA = Meets WCAG 2.2 Level AAA
- ✗ Fail = Does not meet WCAG 2.2 AA

**Notes:**
- Normal text: < 18pt regular or < 14pt bold
- Large text: ≥ 18pt regular or ≥ 14pt bold
- Graphics: UI components, icons, borders (3:1 minimum)

---

## Color Usage Rules Summary

### ✓ APPROVED USES

**AI-State Colors:**
- AEC indicators (processing, analyzing, generating, learning, complete, idle)
- Agent operational mode visualization
- AI computation progress indicators
- Multi-agent differentiation by operational state

**Functional Colors:**
- Success: Form validation, operation completion, positive outcomes
- Warning: Caution states, approaching limits, degraded performance
- Error: Failed operations, critical alerts, destructive action warnings
- Info: System notifications, help content, informational alerts

**Structural Colors:**
- Navy: Primary navigation, headers, footers, hero sections
- Deep Navy: Dark mode backgrounds, elevated modals
- Neutrals: Backgrounds, text, borders, surfaces

**Economic Colors:**
- Credit: Balance displays, available funds
- Debit: Charges, expenditures, consumption
- Fiat: USD/EUR/GBP pricing, invoices
- Neutral: Free tier, zero-cost indicators

### ✗ PROHIBITED USES

**DO NOT:**
- Use AI-state colors for non-AI operations (e.g., Crimson for generic errors)
- Use Emerald for non-AI success states (use functional Success instead)
- Use Amber for warnings (use functional Warning instead)
- Mix AI-state and functional colors semantically
- Apply gradients to AI-state colors for decoration
- Modify canonical color HEX values
- Use color as sole information indicator (WCAG violation)

---

## Version Control

**Document Version:** R.2.0  
**Authority:** CRAV_DYNAMIC_MATERIAL_BRAND_CANON_v1  
**Last Updated:** 2026-01-19  
**Status:** Implementation-Ready Canonical Specification
