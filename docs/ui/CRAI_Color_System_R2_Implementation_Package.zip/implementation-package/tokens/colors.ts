/**
 * CRAI Color System — R.2.0 (Harmonized Canon Edition)
 * TypeScript Color Tokens
 * 
 * Authority: CRAV_DYNAMIC_MATERIAL_BRAND_CANON_v1
 * Generated: 2026-01-19
 * 
 * Provides type-safe access to all color tokens with autocomplete support.
 */

// ========================================
// TYPE DEFINITIONS
// ========================================

export type HexColor = `#${string}`;

export type AIStateColor = 'crimson' | 'cyan' | 'violet' | 'amber' | 'emerald' | 'graphite';
export type StructuralColor = 'navy' | 'deep-navy';
export type NeutralShade = '0' | '50' | '100' | '200' | '300' | '400' | '500' | '600' | '700' | '800' | '900';
export type FunctionalColor = 'success' | 'warning' | 'error' | 'info';
export type EconomicColor = 'credit' | 'debit' | 'fiat' | 'neutral';
export type TierColor = 'free' | 'basic' | 'professional' | 'enterprise';
export type DataColor = 'primary' | 'secondary' | 'tertiary' | 'quaternary' | 'quinary' | 'senary';
export type AgentColor = 'javari' | 'amara' | 'agent-03' | 'agent-04';
export type AECState = 'processing' | 'analyzing' | 'generating' | 'learning' | 'complete' | 'idle' | 'error';

// ========================================
// CANONICAL AI-STATE COLORS (IMMUTABLE)
// ========================================

export const AIStateColors: Record<AIStateColor, HexColor> = {
  crimson: '#DC143C',
  cyan: '#00CED1',
  violet: '#8A2BE2',
  amber: '#FFBF00',
  emerald: '#50C878',
  graphite: '#4A4A4A',
} as const;

// ========================================
// STRUCTURAL COLORS (CANONICAL)
// ========================================

export const StructuralColors: Record<StructuralColor, HexColor> = {
  navy: '#001F3F',
  'deep-navy': '#000D1A',
} as const;

// ========================================
// STRUCTURAL NEUTRALS
// ========================================

export const StructuralNeutralsLight: Record<NeutralShade, HexColor> = {
  '0': '#FFFFFF',
  '50': '#FAFAFA',
  '100': '#F5F5F5',
  '200': '#E5E5E5',
  '300': '#D4D4D4',
  '400': '#A3A3A3',
  '500': '#737373',
  '600': '#525252',
  '700': '#262626',
  '800': '#171717',
  '900': '#0A0A0A',
} as const;

export const StructuralNeutralsDark: Record<NeutralShade, HexColor> = {
  '0': '#0F0F0F',
  '50': '#1A1A1A',
  '100': '#262626',
  '200': '#3D3D3D',
  '300': '#525252',
  '400': '#737373',
  '500': '#A3A3A3',
  '600': '#D4D4D4',
  '700': '#E5E5E5',
  '800': '#F5F5F5',
  '900': '#FAFAFA',
} as const;

// ========================================
// FUNCTIONAL COLORS
// ========================================

export const FunctionalColors = {
  success: {
    primary: '#16A34A' as HexColor,
    bg: '#DCFCE7' as HexColor,
    bgDark: '#14532D' as HexColor,
    border: '#86EFAC' as HexColor,
  },
  warning: {
    primary: '#D97706' as HexColor,
    bg: '#FEF3C7' as HexColor,
    bgDark: '#78350F' as HexColor,
    border: '#FCD34D' as HexColor,
  },
  error: {
    primary: '#DC2626' as HexColor,
    bg: '#FEE2E2' as HexColor,
    bgDark: '#7F1D1D' as HexColor,
    border: '#FCA5A5' as HexColor,
  },
  info: {
    primary: '#0284C7' as HexColor,
    bg: '#E0F2FE' as HexColor,
    bgDark: '#0C4A6E' as HexColor,
    border: '#7DD3FC' as HexColor,
  },
} as const;

// ========================================
// ECONOMIC COLORS
// ========================================

export const EconomicColors: Record<EconomicColor, HexColor> = {
  credit: '#0891B2',
  debit: '#DC2626',
  fiat: '#15803D',
  neutral: '#525252',
} as const;

export const TierColors: Record<TierColor, HexColor> = {
  free: '#525252',
  basic: '#0891B2',
  professional: '#7C3AED',
  enterprise: '#001F3F',
} as const;

// ========================================
// DATA VISUALIZATION COLORS
// ========================================

export const DataColors: Record<DataColor, HexColor> = {
  primary: '#0891B2',
  secondary: '#DB2777',
  tertiary: '#9333EA',
  quaternary: '#EA580C',
  quinary: '#65A30D',
  senary: '#0369A1',
} as const;

// ========================================
// AGENT SIGNATURE COLORS
// ========================================

export const AgentColors: Record<AgentColor, HexColor> = {
  javari: '#0C4A6E',
  amara: '#7C2D12',
  'agent-03': '#365314',
  'agent-04': '#581C87',
} as const;

// ========================================
// AEC STATE COLORS
// ========================================

export const AECStateColors: Record<AECState, HexColor> = {
  processing: AIStateColors.crimson,
  analyzing: AIStateColors.cyan,
  generating: AIStateColors.violet,
  learning: AIStateColors.amber,
  complete: AIStateColors.emerald,
  idle: AIStateColors.graphite,
  error: FunctionalColors.error.primary,
} as const;

// ========================================
// HELPER FUNCTIONS
// ========================================

/**
 * Get an AI-state color by name
 * @example getAIStateColor('crimson') // '#DC143C'
 */
export function getAIStateColor(color: AIStateColor): HexColor {
  return AIStateColors[color];
}

/**
 * Get a structural color by name
 * @example getStructuralColor('navy') // '#001F3F'
 */
export function getStructuralColor(color: StructuralColor): HexColor {
  return StructuralColors[color];
}

/**
 * Get a neutral color by shade (light mode)
 * @example getNeutralColor('700') // '#262626'
 */
export function getNeutralColor(shade: NeutralShade): HexColor {
  return StructuralNeutralsLight[shade];
}

/**
 * Get a neutral color by shade (dark mode)
 * @example getNeutralColorDark('700') // '#E5E5E5'
 */
export function getNeutralColorDark(shade: NeutralShade): HexColor {
  return StructuralNeutralsDark[shade];
}

/**
 * Get a functional color by type
 * @example getFunctionalColor('success') // { primary: '#16A34A', bg: '#DCFCE7', ... }
 */
export function getFunctionalColor(type: FunctionalColor) {
  return FunctionalColors[type];
}

/**
 * Get an economic color by type
 * @example getEconomicColor('credit') // '#0891B2'
 */
export function getEconomicColor(type: EconomicColor): HexColor {
  return EconomicColors[type];
}

/**
 * Get a tier color by type
 * @example getTierColor('enterprise') // '#001F3F'
 */
export function getTierColor(tier: TierColor): HexColor {
  return TierColors[tier];
}

/**
 * Get a data visualization color by series
 * @example getDataColor('primary') // '#0891B2'
 */
export function getDataColor(series: DataColor): HexColor {
  return DataColors[series];
}

/**
 * Get an agent signature color by agent name
 * @example getAgentColor('javari') // '#0C4A6E'
 */
export function getAgentColor(agent: AgentColor): HexColor {
  return AgentColors[agent];
}

/**
 * Get an AEC state color by state
 * @example getAECColor('processing') // '#DC143C'
 */
export function getAECColor(state: AECState): HexColor {
  return AECStateColors[state];
}

// ========================================
// CSS VARIABLE HELPERS
// ========================================

/**
 * Get CSS variable name for AI-state color
 * @example getAIStateVar('crimson') // 'var(--color-ai-crimson)'
 */
export function getAIStateVar(color: AIStateColor): string {
  return `var(--color-ai-${color})`;
}

/**
 * Get CSS variable name for structural color
 * @example getStructuralVar('navy') // 'var(--color-structural-navy)'
 */
export function getStructuralVar(color: StructuralColor): string {
  return `var(--color-structural-${color})`;
}

/**
 * Get CSS variable name for neutral color
 * @example getNeutralVar('700') // 'var(--color-structural-neutral-700)'
 */
export function getNeutralVar(shade: NeutralShade): string {
  return `var(--color-structural-neutral-${shade})`;
}

/**
 * Get CSS variable name for functional color
 * @example getFunctionalVar('success') // 'var(--color-functional-success)'
 */
export function getFunctionalVar(type: FunctionalColor): string {
  return `var(--color-functional-${type})`;
}

/**
 * Get CSS variable name for AEC state
 * @example getAECVar('processing') // 'var(--aec-processing)'
 */
export function getAECVar(state: AECState): string {
  return `var(--aec-${state})`;
}

// ========================================
// CONTRAST VALIDATION
// ========================================

/**
 * WCAG contrast ratios for key color pairings
 * Values represent contrast ratio against white (#FFFFFF)
 */
export const ContrastRatios = {
  aiState: {
    crimson: 5.04,
    cyan: 3.26, // Fails AA for normal text
    violet: 5.65,
    amber: 2.36, // Fails AA for text
    emerald: 3.52, // Fails AA for normal text
    graphite: 12.63,
  },
  functional: {
    success: 4.89,
    warning: 4.54,
    error: 5.54,
    info: 4.98,
  },
  neutrals: {
    '500': 4.54,
    '600': 8.51,
    '700': 12.63,
  },
} as const;

/**
 * Check if color meets WCAG AA contrast for normal text (4.5:1)
 */
export function meetsWCAGAA(contrastRatio: number): boolean {
  return contrastRatio >= 4.5;
}

/**
 * Check if color meets WCAG AAA contrast for normal text (7:1)
 */
export function meetsWCAGAAA(contrastRatio: number): boolean {
  return contrastRatio >= 7.0;
}

// ========================================
// COLOR UTILITIES
// ========================================

/**
 * Convert HEX to RGB
 * @example hexToRgb('#DC143C') // { r: 220, g: 20, b: 60 }
 */
export function hexToRgb(hex: HexColor): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : null;
}

/**
 * Convert RGB to HEX
 * @example rgbToHex(220, 20, 60) // '#DC143C'
 */
export function rgbToHex(r: number, g: number, b: number): HexColor {
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase()}` as HexColor;
}

// ========================================
// EXPORTS
// ========================================

export default {
  AIStateColors,
  StructuralColors,
  StructuralNeutralsLight,
  StructuralNeutralsDark,
  FunctionalColors,
  EconomicColors,
  TierColors,
  DataColors,
  AgentColors,
  AECStateColors,
  ContrastRatios,
};
