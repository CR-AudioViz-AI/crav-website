# AEC Indicator Component Specification
**CRAI Color System R.2.0**

## Overview

AEC (AI Energy Cell) indicators are visual components representing AI computational state, credit consumption, and operational mode. They appear throughout the platform in chat interfaces, agent avatars, dashboard widgets, and processing indicators.

---

## AEC States & Colors

| State | Color | HEX | Animation | Usage |
|-------|-------|-----|-----------|-------|
| Processing | Crimson | `#DC143C` | Pulsing (0.8s) | Active computation, generating response |
| Analyzing | Cyan | `#00CED1` | Rotating particles (2s) | Data synthesis, querying knowledge |
| Generating | Violet | `#8A2BE2` | Shimmer effect (1.5s) | Content creation, artifact generation |
| Learning | Amber | `#FFBF00` | Progressive fill | Training, knowledge ingestion |
| Complete | Emerald | `#50C878` | Static / check pulse | Operation successful |
| Idle | Graphite | `#4A4A4A` | Static, 40% opacity | Inactive, awaiting input |
| Error | Error Red | `#DC2626` | Static with alert icon | Operation failed |

---

## Size Standards

```css
:root {
  --aec-size-sm: 16px;
  --aec-size-md: 24px;
  --aec-size-lg: 48px;
  --aec-size-xl: 96px;
}
```

---

## Base Component Structure

### HTML Structure
```html
<div 
  class="aec-indicator aec-indicator--processing aec-indicator--md" 
  role="status" 
  aria-label="Agent is processing"
>
  <div class="aec-indicator__ring"></div>
  <div class="aec-indicator__fill"></div>
</div>
```

### Base CSS
```css
.aec-indicator {
  position: relative;
  display: inline-block;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Size variants */
.aec-indicator--sm {
  width: var(--aec-size-sm);
  height: var(--aec-size-sm);
}

.aec-indicator--md {
  width: var(--aec-size-md);
  height: var(--aec-size-md);
}

.aec-indicator--lg {
  width: var(--aec-size-lg);
  height: var(--aec-size-lg);
}

.aec-indicator--xl {
  width: var(--aec-size-xl);
  height: var(--aec-size-xl);
}

/* Ring element */
.aec-indicator__ring {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  border: 2px solid currentColor;
}

/* Fill element */
.aec-indicator__fill {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background-color: currentColor;
}
```

---

## State-Specific Implementations

### 1. Processing (Crimson Pulse)

**Animation:** Pulsing opacity 100% → 60% → 100%

```css
.aec-indicator--processing {
  color: var(--aec-processing); /* Crimson */
}

.aec-indicator--processing .aec-indicator__fill {
  animation: aec-pulse 0.8s ease-in-out infinite;
}

@keyframes aec-pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.6;
  }
}
```

---

### 2. Analyzing (Cyan Rotating Particles)

**Animation:** Clockwise rotation with particle segments

```css
.aec-indicator--analyzing {
  color: var(--aec-analyzing); /* Cyan */
}

.aec-indicator--analyzing .aec-indicator__fill {
  background: transparent;
}

.aec-indicator--analyzing .aec-indicator__ring {
  border: none;
  background: conic-gradient(
    from 0deg,
    transparent 0deg,
    transparent 60deg,
    currentColor 60deg,
    currentColor 120deg,
    transparent 120deg,
    transparent 180deg,
    currentColor 180deg,
    currentColor 240deg,
    transparent 240deg,
    transparent 300deg,
    currentColor 300deg,
    currentColor 360deg
  );
  animation: aec-rotate 2s linear infinite;
}

@keyframes aec-rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
```

---

### 3. Generating (Violet Shimmer)

**Animation:** Diagonal gradient sweep

```css
.aec-indicator--generating {
  color: var(--aec-generating); /* Violet */
  overflow: hidden;
}

.aec-indicator--generating .aec-indicator__fill {
  background: linear-gradient(
    45deg,
    var(--aec-generating) 0%,
    var(--aec-generating) 40%,
    rgba(138, 43, 226, 0.6) 50%,
    var(--aec-generating) 60%,
    var(--aec-generating) 100%
  );
  background-size: 200% 200%;
  animation: aec-shimmer 1.5s ease-in-out infinite;
}

@keyframes aec-shimmer {
  0% {
    background-position: 0% 0%;
  }
  50% {
    background-position: 100% 100%;
  }
  100% {
    background-position: 0% 0%;
  }
}
```

---

### 4. Learning (Amber Progressive Fill)

**Animation:** Bottom-to-top fill based on progress

```css
.aec-indicator--learning {
  color: var(--aec-learning); /* Amber */
}

.aec-indicator--learning .aec-indicator__fill {
  background: transparent;
}

.aec-indicator--learning .aec-indicator__ring {
  border: none;
  background: conic-gradient(
    from -90deg,
    var(--aec-learning) 0%,
    var(--aec-learning) var(--aec-progress, 0%),
    transparent var(--aec-progress, 0%),
    transparent 100%
  );
  animation: aec-learning-progress 3s ease-out;
}

@keyframes aec-learning-progress {
  from {
    --aec-progress: 0%;
  }
  to {
    --aec-progress: 100%;
  }
}
```

**With Dynamic Progress:**
```html
<div 
  class="aec-indicator aec-indicator--learning aec-indicator--md"
  style="--aec-progress: 65%"
  role="status"
  aria-label="Agent is learning (65% complete)"
>
  <div class="aec-indicator__ring"></div>
</div>
```

---

### 5. Complete (Emerald Static)

**Animation:** Optional single check pulse

```css
.aec-indicator--complete {
  color: var(--aec-complete); /* Emerald */
}

.aec-indicator--complete .aec-indicator__fill {
  animation: none; /* Static by default */
}

/* Optional check icon overlay */
.aec-indicator--complete::after {
  content: '✓';
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 0.6em;
  font-weight: bold;
}
```

---

### 6. Idle (Graphite Static)

**Animation:** None, reduced opacity

```css
.aec-indicator--idle {
  color: var(--aec-idle); /* Graphite */
  opacity: 0.4;
}

.aec-indicator--idle .aec-indicator__fill {
  animation: none;
}
```

---

### 7. Error (Error Red Static)

**Animation:** None, alert icon

```css
.aec-indicator--error {
  color: var(--status-error); /* Error red, not Crimson */
}

.aec-indicator--error .aec-indicator__fill {
  animation: none;
}

.aec-indicator--error::after {
  content: '✕';
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 0.6em;
  font-weight: bold;
}
```

---

## Credit Consumption Visualization

AECs can visualize credit consumption rate through ring thickness:

```css
.aec-indicator--rate-low .aec-indicator__ring {
  border-width: 2px;
}

.aec-indicator--rate-medium .aec-indicator__ring {
  border-width: 4px;
}

.aec-indicator--rate-high .aec-indicator__ring {
  border-width: 6px;
  animation-duration: 1s; /* Faster animation for high consumption */
}
```

**HTML Example:**
```html
<div class="aec-indicator aec-indicator--processing aec-indicator--md aec-indicator--rate-high">
  <div class="aec-indicator__ring"></div>
  <div class="aec-indicator__fill"></div>
</div>
```

---

## Reduced Motion Support

**CRITICAL:** Users with motion sensitivity must see static colors

```css
@media (prefers-reduced-motion: reduce) {
  .aec-indicator * {
    animation: none !important;
    transition: none !important;
  }
  
  /* Show static color fills for reduced motion */
  .aec-indicator--processing .aec-indicator__fill,
  .aec-indicator--analyzing .aec-indicator__fill,
  .aec-indicator--generating .aec-indicator__fill {
    opacity: 1;
    background-color: currentColor;
  }
}
```

---

## React Implementation

### TypeScript Component

```tsx
import React from 'react';
import { AECState } from '@/tokens/colors';

interface AECIndicatorProps {
  state: AECState;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  creditRate?: 'low' | 'medium' | 'high';
  progress?: number; // For learning state (0-100)
  className?: string;
}

export const AECIndicator: React.FC<AECIndicatorProps> = ({
  state,
  size = 'md',
  creditRate = 'low',
  progress,
  className = '',
}) => {
  const ariaLabel = `Agent is ${state}${progress ? ` (${progress}% complete)` : ''}`;
  
  const style = state === 'learning' && progress !== undefined
    ? { '--aec-progress': `${progress}%` } as React.CSSProperties
    : undefined;
  
  return (
    <div
      className={`aec-indicator aec-indicator--${state} aec-indicator--${size} aec-indicator--rate-${creditRate} ${className}`}
      role="status"
      aria-label={ariaLabel}
      style={style}
    >
      <div className="aec-indicator__ring"></div>
      <div className="aec-indicator__fill"></div>
    </div>
  );
};
```

### Usage Examples

```tsx
// Processing state
<AECIndicator state="processing" size="md" />

// Analyzing with high credit consumption
<AECIndicator state="analyzing" size="lg" creditRate="high" />

// Learning with progress
<AECIndicator state="learning" size="md" progress={65} />

// Complete state
<AECIndicator state="complete" size="sm" />

// Error state
<AECIndicator state="error" size="md" />
```

---

## Integration with Agent Avatars

AECs overlay on agent avatars (bottom-right corner):

```css
.agent-avatar {
  position: relative;
  width: var(--avatar-size-md);
  height: var(--avatar-size-md);
}

.agent-avatar__aec {
  position: absolute;
  bottom: -2px;
  right: -2px;
  width: 50%; /* Half avatar size */
  height: 50%;
  border: 2px solid var(--bg-primary); /* White border for definition */
  border-radius: 50%;
}
```

**HTML Example:**
```html
<div class="agent-avatar">
  <img src="agent.svg" alt="Javari AI" />
  <div class="agent-avatar__aec">
    <div class="aec-indicator aec-indicator--processing aec-indicator--sm">
      <div class="aec-indicator__ring"></div>
      <div class="aec-indicator__fill"></div>
    </div>
  </div>
</div>
```

---

## Multi-Agent Coordination

When multiple agents operate simultaneously:

1. **Active agent:** Full saturation AEC with animation
2. **Background agents:** 60% opacity AEC with animation
3. **Idle agents:** Graphite AEC at 40% opacity, no animation

```css
.agent-list__item--active .aec-indicator {
  opacity: 1;
}

.agent-list__item--background .aec-indicator {
  opacity: 0.6;
}

.agent-list__item--idle .aec-indicator {
  opacity: 0.4;
}
```

**Stagger animations** to prevent synchronized pulsing:

```css
.agent-list__item:nth-child(1) .aec-indicator {
  animation-delay: 0s;
}

.agent-list__item:nth-child(2) .aec-indicator {
  animation-delay: 0.3s;
}

.agent-list__item:nth-child(3) .aec-indicator {
  animation-delay: 0.6s;
}
```

---

## Performance Optimization

### GPU Acceleration

```css
.aec-indicator,
.aec-indicator__ring,
.aec-indicator__fill {
  will-change: transform, opacity;
  transform: translateZ(0); /* Force GPU layer */
}
```

### Limit Simultaneous Animations

JavaScript logic to limit active AECs:

```typescript
const MAX_ACTIVE_AECS = 3;

function limitActiveAECs(agents: Agent[]) {
  const processingAgents = agents.filter(a => a.aecState !== 'idle');
  
  if (processingAgents.length > MAX_ACTIVE_AECS) {
    // Show AEC for top 3 priority agents, collapse others
    return processingAgents.slice(0, MAX_ACTIVE_AECS);
  }
  
  return processingAgents;
}
```

---

## Accessibility Requirements

### Non-Color Indicators
- AEC color NEVER sole indicator of state
- Text label or ARIA attribute required
- Example: `<div role="status" aria-label="Agent is processing">`

### Screen Reader Announcements
```html
<div 
  class="aec-indicator aec-indicator--processing"
  role="status"
  aria-live="polite"
  aria-label="Agent is processing your request"
>
  <!-- AEC visual -->
</div>
```

### Reduced Motion
- All animations disabled via `prefers-reduced-motion`
- Static color fills shown instead
- State still communicated via color + ARIA label

---

## Testing Checklist

- [ ] All 7 AEC states render correctly
- [ ] Animations function in supporting browsers
- [ ] Animations disabled for `prefers-reduced-motion`
- [ ] ARIA labels present on all instances
- [ ] AEC colors match canonical values exactly
- [ ] Credit rate visualization (ring thickness) works
- [ ] Progress indicator (learning state) updates correctly
- [ ] AECs overlay correctly on agent avatars
- [ ] Multi-agent staggered animations prevent visual noise
- [ ] Performance acceptable with 3+ simultaneous AECs
