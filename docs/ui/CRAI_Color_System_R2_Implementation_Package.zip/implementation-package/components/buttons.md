# Button Component Integration Guide
**CRAI Color System R.2.0**

## Overview

Button components use the canonical color system to communicate hierarchy, intent, and action safety. This guide provides implementation specifications for all button variants.

---

## Button Variants

### 1. Primary Button

**Usage:** Main call-to-action, highest priority actions  
**Color Tokens:**
- Background: `--btn-primary-bg` (Navy `#001F3F`)
- Text: `--btn-primary-text` (White `#FFFFFF`)
- Hover Background: `--btn-primary-hover-bg` (Cyan `#00CED1`)

**CSS Implementation:**
```css
.btn-primary {
  background-color: var(--btn-primary-bg);
  color: var(--btn-primary-text);
  border: none;
  padding: 0.75rem 1.5rem;
  font-size: 14px;
  font-weight: 500;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.btn-primary:hover {
  background-color: var(--btn-primary-hover-bg);
}

.btn-primary:focus-visible {
  outline: 2px solid var(--color-focus-indicator);
  outline-offset: 2px;
}

.btn-primary:disabled {
  background-color: var(--color-structural-neutral-400);
  cursor: not-allowed;
  opacity: 0.6;
}
```

**React/TypeScript Implementation:**
```tsx
interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
}

export const PrimaryButton: React.FC<ButtonProps> = ({ children, onClick, disabled }) => {
  return (
    <button
      className="btn-primary"
      onClick={onClick}
      disabled={disabled}
      type="button"
    >
      {children}
    </button>
  );
};
```

**WCAG Compliance:**
- Contrast Ratio (Text on Navy): 21:1 (AAA)
- Contrast Ratio (Text on Cyan hover): 4.82:1 (AA)
- Focus indicator meets WCAG 2.2 requirements (3:1 contrast)

---

### 2. Secondary Button

**Usage:** Secondary actions, alternative paths  
**Color Tokens:**
- Background: `--btn-secondary-bg` (Neutral-100 `#F5F5F5`)
- Text: `--btn-secondary-text` (Neutral-700 `#262626`)
- Hover Background: `--btn-secondary-hover-bg` (Neutral-200 `#E5E5E5`)
- Border: `--border-default` (Neutral-300 `#D4D4D4`)

**CSS Implementation:**
```css
.btn-secondary {
  background-color: var(--btn-secondary-bg);
  color: var(--btn-secondary-text);
  border: 1px solid var(--border-default);
  padding: 0.75rem 1.5rem;
  font-size: 14px;
  font-weight: 500;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.btn-secondary:hover {
  background-color: var(--btn-secondary-hover-bg);
}

.btn-secondary:focus-visible {
  outline: 2px solid var(--color-focus-indicator);
  outline-offset: 2px;
}

.btn-secondary:disabled {
  background-color: var(--color-structural-neutral-50);
  color: var(--color-structural-neutral-500);
  cursor: not-allowed;
  opacity: 0.6;
}
```

**Dark Mode Variant:**
```css
[data-theme="dark"] .btn-secondary {
  background-color: var(--color-structural-neutral-100);
  color: var(--color-structural-neutral-700);
  border-color: var(--color-structural-neutral-300);
}

[data-theme="dark"] .btn-secondary:hover {
  background-color: var(--color-structural-neutral-200);
}
```

---

### 3. Danger/Destructive Button

**Usage:** Delete, remove, destructive actions requiring confirmation  
**Color Tokens:**
- Background: `--btn-danger-bg` (Error `#DC2626`)
- Text: `--btn-danger-text` (White `#FFFFFF`)
- Hover Background: `--btn-danger-hover-bg` (Darkened Error `#B91C1C`)

**CSS Implementation:**
```css
.btn-danger {
  background-color: var(--btn-danger-bg);
  color: var(--btn-danger-text);
  border: none;
  padding: 0.75rem 1.5rem;
  font-size: 14px;
  font-weight: 500;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.btn-danger:hover {
  background-color: var(--btn-danger-hover-bg);
}

.btn-danger:focus-visible {
  outline: 2px solid var(--color-functional-error);
  outline-offset: 2px;
}

.btn-danger:disabled {
  background-color: var(--color-structural-neutral-400);
  cursor: not-allowed;
  opacity: 0.6;
}
```

**Important:** Danger buttons should always:
1. Include confirmation dialog for irreversible actions
2. Use descriptive text (e.g., "Delete Account" not "Confirm")
3. Be spatially separated from safe actions

---

### 4. Ghost/Text Button

**Usage:** Tertiary actions, inline actions, low-emphasis interactions  
**Color Tokens:**
- Background: Transparent
- Text: `--text-secondary` (Neutral-600 `#525252`)
- Hover Background: `--bg-elevated` (Neutral-100 `#F5F5F5`)

**CSS Implementation:**
```css
.btn-ghost {
  background-color: transparent;
  color: var(--text-secondary);
  border: none;
  padding: 0.75rem 1.5rem;
  font-size: 14px;
  font-weight: 500;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.btn-ghost:hover {
  background-color: var(--bg-elevated);
}

.btn-ghost:focus-visible {
  outline: 2px solid var(--color-focus-indicator);
  outline-offset: 2px;
}

.btn-ghost:disabled {
  color: var(--color-structural-neutral-400);
  cursor: not-allowed;
}
```

---

### 5. AEC Action Button

**Usage:** Buttons that trigger AI operations (run analysis, generate content, etc.)  
**Color Tokens:**
- Background: Varies by AEC state (Processing: Crimson, Generating: Violet, etc.)
- Text: White `#FFFFFF`
- AEC Indicator: Embedded, state-specific

**CSS Implementation:**
```css
.btn-aec {
  background-color: var(--aec-processing); /* Default to processing state */
  color: #FFFFFF;
  border: none;
  padding: 0.75rem 1.5rem 0.75rem 3rem; /* Extra left padding for AEC */
  font-size: 14px;
  font-weight: 500;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  transition: background-color 0.2s ease;
}

/* AEC indicator positioned left */
.btn-aec::before {
  content: '';
  position: absolute;
  left: 1rem;
  top: 50%;
  transform: translateY(-50%);
  width: 16px;
  height: 16px;
  background-color: currentColor;
  border-radius: 50%;
  opacity: 0.8;
}

/* State-specific variants */
.btn-aec--processing { background-color: var(--aec-processing); }
.btn-aec--analyzing { background-color: var(--aec-analyzing); }
.btn-aec--generating { background-color: var(--aec-generating); }
.btn-aec--learning { background-color: var(--aec-learning); }

.btn-aec:disabled {
  background-color: var(--aec-idle);
  cursor: not-allowed;
}
```

**React Implementation with AEC State:**
```tsx
interface AECButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  aecState?: 'processing' | 'analyzing' | 'generating' | 'learning' | 'idle';
  disabled?: boolean;
}

export const AECButton: React.FC<AECButtonProps> = ({ 
  children, 
  onClick, 
  aecState = 'processing',
  disabled 
}) => {
  return (
    <button
      className={`btn-aec btn-aec--${aecState}`}
      onClick={onClick}
      disabled={disabled}
      aria-label={`${children} (AI ${aecState})`}
    >
      {children}
    </button>
  );
};
```

---

## Button Sizing

### Size Variants

**Large (lg):**
```css
.btn-lg {
  padding: 1rem 2rem;
  font-size: 16px;
}
```

**Medium (md) - Default:**
```css
.btn-md {
  padding: 0.75rem 1.5rem;
  font-size: 14px;
}
```

**Small (sm):**
```css
.btn-sm {
  padding: 0.5rem 1rem;
  font-size: 13px;
}
```

---

## Icon Buttons

**Usage:** Actions represented by icon only  
**Requirements:**
1. ARIA label required for accessibility
2. Minimum touch target 44×44px
3. Tooltip on hover recommended

**CSS Implementation:**
```css
.btn-icon {
  background-color: transparent;
  color: var(--text-secondary);
  border: none;
  padding: 0.5rem;
  min-width: 44px;
  min-height: 44px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.btn-icon:hover {
  background-color: var(--bg-elevated);
}

.btn-icon:focus-visible {
  outline: 2px solid var(--color-focus-indicator);
  outline-offset: 2px;
}
```

**HTML Example:**
```html
<button class="btn-icon" aria-label="Delete item">
  <svg><!-- trash icon --></svg>
</button>
```

---

## Loading States

**Implementation:** Replace button text with spinner, maintain width

**CSS Implementation:**
```css
.btn-loading {
  position: relative;
  color: transparent;
  pointer-events: none;
}

.btn-loading::after {
  content: '';
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 16px;
  height: 16px;
  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
  color: var(--btn-primary-text); /* Inherit from button variant */
}

@keyframes spin {
  to { transform: translate(-50%, -50%) rotate(360deg); }
}
```

**React Implementation:**
```tsx
interface LoadingButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  loading?: boolean;
}

export const LoadingButton: React.FC<LoadingButtonProps> = ({ 
  children, 
  onClick, 
  loading 
}) => {
  return (
    <button
      className={`btn-primary ${loading ? 'btn-loading' : ''}`}
      onClick={onClick}
      disabled={loading}
    >
      {children}
    </button>
  );
};
```

---

## Accessibility Requirements

### Focus States
- All buttons MUST have visible focus indicator
- Focus outline: 2px solid, 2px offset
- Keyboard navigation support required

### Contrast Requirements
- Primary button: White text on Navy (21:1 contrast)
- Secondary button: Dark text on light background (12.63:1 contrast)
- Danger button: White text on red (5.54:1 contrast)
- All buttons meet WCAG AA minimum (4.5:1)

### Touch Targets
- Minimum touch target: 44×44px
- Padding ensures adequate hit area
- Icon-only buttons use explicit min-width/min-height

### Screen Reader Support
- Descriptive button text (avoid "Click here")
- Loading state announced via aria-live
- Icon-only buttons require aria-label
- Disabled state communicated via disabled attribute

---

## Button Groups

**Usage:** Related actions grouped together

**CSS Implementation:**
```css
.btn-group {
  display: inline-flex;
  gap: 0.5rem;
}

.btn-group .btn-secondary:not(:last-child) {
  border-right: none;
}
```

**HTML Example:**
```html
<div class="btn-group">
  <button class="btn-secondary">Cancel</button>
  <button class="btn-primary">Save</button>
</div>
```

---

## Common Patterns

### Confirmation Dialog Buttons
```html
<div class="btn-group">
  <button class="btn-secondary">Cancel</button>
  <button class="btn-danger">Delete Account</button>
</div>
```

### Form Submit Buttons
```html
<div class="btn-group">
  <button type="button" class="btn-secondary">Reset</button>
  <button type="submit" class="btn-primary">Submit</button>
</div>
```

### Inline Actions
```html
<button class="btn-ghost">Edit</button>
<button class="btn-ghost">Delete</button>
```

---

## Testing Checklist

- [ ] All button variants render correctly in light mode
- [ ] All button variants render correctly in dark mode
- [ ] Focus states visible on keyboard navigation
- [ ] Hover states functional
- [ ] Disabled states visually distinct and non-interactive
- [ ] Loading states preserve button width
- [ ] Touch targets meet 44×44px minimum
- [ ] Screen reader announces button purpose
- [ ] Color contrast meets WCAG AA
- [ ] AEC buttons display correct state colors
