# CRAI Color System R.2.0 Implementation Guide
**Step-by-Step Deployment Instructions**

---

## 🎯 Overview

This guide provides systematic instructions for deploying the CRAI Color System R.2.0 across your platform. Follow these steps in order to ensure proper integration with zero breaking changes.

**Estimated Time:** 4-6 weeks for complete deployment  
**Team Size:** 2-3 frontend engineers, 1 designer, 1 QA engineer

---

## 📋 Pre-Implementation Checklist

Before beginning implementation:

- [ ] Review Brand Foundation R.1.0
- [ ] Review Visual Strategy R.1.1
- [ ] Review CRAI Color System Specification R.2.0
- [ ] Backup current production codebase
- [ ] Create feature branch: `feature/color-system-r2`
- [ ] Set up staging environment for testing
- [ ] Schedule design/engineering alignment meeting

---

## Phase 1: Token Infrastructure (Week 1)

### Step 1.1: Install Color Token Files

**Action:** Copy token files to your project

```bash
# Copy CSS tokens
cp implementation-package/tokens/colors.css src/styles/tokens/

# Copy SCSS tokens (if using SCSS)
cp implementation-package/tokens/colors.scss src/styles/tokens/

# Copy TypeScript tokens (if using TypeScript)
cp implementation-package/tokens/colors.ts src/tokens/
```

**Validation:**
- [ ] Files copied to correct locations
- [ ] No import errors in build

---

### Step 1.2: Import Tokens in Global Styles

**CSS:**

```css
/* src/styles/global.css */
@import './tokens/colors.css';

/* Set default theme */
:root {
  /* Tokens already defined in colors.css */
}
```

**SCSS:**

```scss
// src/styles/global.scss
@import './tokens/colors';

// Example usage
.button-primary {
  background-color: structural('navy');
  color: neutral('0');
}
```

**TypeScript:**

```typescript
// src/app.tsx or main entry point
import colors from '@/tokens/colors';

// TypeScript types now available for autocomplete
```

**Validation:**
- [ ] CSS variables accessible globally
- [ ] SCSS helper functions working
- [ ] TypeScript autocomplete functional
- [ ] No console errors

---

### Step 1.3: Configure Theme Switching

**HTML Setup:**

```html
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <link rel="stylesheet" href="/styles/global.css">
</head>
<body>
  <!-- App content -->
</body>
</html>
```

**JavaScript Theme Toggle:**

```javascript
// src/utils/theme.ts
export function setTheme(theme: 'light' | 'dark') {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('preferred-theme', theme);
}

export function initTheme() {
  const saved = localStorage.getItem('preferred-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  const theme = saved || (prefersDark ? 'dark' : 'light');
  setTheme(theme);
}

// Call on app initialization
initTheme();
```

**React Theme Toggle Component:**

```tsx
// src/components/ThemeToggle.tsx
import { useState, useEffect } from 'react';
import { setTheme } from '@/utils/theme';

export function ThemeToggle() {
  const [isDark, setIsDark] = useState(false);
  
  useEffect(() => {
    const theme = document.documentElement.getAttribute('data-theme');
    setIsDark(theme === 'dark');
  }, []);
  
  const toggle = () => {
    const newTheme = isDark ? 'light' : 'dark';
    setTheme(newTheme);
    setIsDark(!isDark);
  };
  
  return (
    <button onClick={toggle} aria-label="Toggle theme">
      {isDark ? '☀️' : '🌙'}
    </button>
  );
}
```

**Validation:**
- [ ] Theme persists across page reloads
- [ ] System preference respected on first visit
- [ ] Dark mode neutrals invert correctly
- [ ] AI-state colors remain consistent across modes

---

### Step 1.4: Set Up Build Validation

**ESLint Rule (Prevent Hardcoded Colors):**

```javascript
// .eslintrc.js
module.exports = {
  rules: {
    'no-hardcoded-colors': {
      pattern: /#[0-9A-Fa-f]{3,6}/,
      message: 'Use semantic color tokens instead of hardcoded HEX values'
    }
  }
};
```

**Pre-commit Hook:**

```bash
# .husky/pre-commit
#!/bin/sh
npm run lint
npm run type-check
```

**Validation:**
- [ ] Linting catches hardcoded HEX values
- [ ] Type checking validates token usage
- [ ] Pre-commit hooks functional

---

## Phase 2: Component Migration (Weeks 2-3)

### Step 2.1: Audit Existing Components

**Action:** Identify all components using colors

```bash
# Search for hardcoded HEX values
grep -r "#[0-9A-Fa-f]\{6\}" src/components/

# Search for RGB values
grep -r "rgb(" src/components/

# Search for background-color/color properties
grep -r "background-color:" src/components/
grep -r "color:" src/components/
```

**Create Audit Spreadsheet:**

| Component | File Path | Current Colors | Token Replacement | Status |
|-----------|-----------|----------------|-------------------|--------|
| Button | components/Button.tsx | #001F3F | var(--btn-primary-bg) | Pending |
| ... | ... | ... | ... | ... |

**Validation:**
- [ ] All components catalogued
- [ ] Replacement tokens identified
- [ ] Migration priority assigned

---

### Step 2.2: Migrate High-Priority Components

**Priority Order:**

1. Buttons (highest visibility)
2. Navigation
3. Forms & Inputs
4. Status badges
5. Cards & Tables
6. Dashboards

**Example: Button Migration**

**Before:**

```tsx
// components/Button.tsx - OLD
const Button = ({ variant = 'primary', children }) => {
  const styles = {
    primary: {
      backgroundColor: '#001F3F',
      color: '#FFFFFF',
    },
    secondary: {
      backgroundColor: '#F5F5F5',
      color: '#262626',
    }
  };
  
  return (
    <button style={styles[variant]}>
      {children}
    </button>
  );
};
```

**After:**

```tsx
// components/Button.tsx - NEW
const Button = ({ variant = 'primary', children }) => {
  return (
    <button className={`btn btn-${variant}`}>
      {children}
    </button>
  );
};

// components/Button.css
.btn-primary {
  background-color: var(--btn-primary-bg);
  color: var(--btn-primary-text);
}

.btn-primary:hover {
  background-color: var(--btn-primary-hover-bg);
}

.btn-secondary {
  background-color: var(--btn-secondary-bg);
  color: var(--btn-secondary-text);
  border: 1px solid var(--border-default);
}

.btn-secondary:hover {
  background-color: var(--btn-secondary-hover-bg);
}
```

**Validation:**
- [ ] Visual regression tests pass
- [ ] Light/dark modes tested
- [ ] Hover/focus states functional
- [ ] Accessibility contrast maintained

---

### Step 2.3: Implement AEC Indicator Component

**Copy Animation Styles:**

```bash
cp implementation-package/animations/aec-animations.css src/styles/components/
```

**Import in Global Styles:**

```css
/* src/styles/global.css */
@import './tokens/colors.css';
@import './components/aec-animations.css';
```

**Create React Component:**

```tsx
// src/components/AECIndicator.tsx
import './AECIndicator.css';

interface AECIndicatorProps {
  state: 'processing' | 'analyzing' | 'generating' | 'learning' | 'complete' | 'idle' | 'error';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  creditRate?: 'low' | 'medium' | 'high';
  progress?: number;
}

export function AECIndicator({
  state,
  size = 'md',
  creditRate = 'low',
  progress
}: AECIndicatorProps) {
  const ariaLabel = `Agent is ${state}${progress ? ` (${progress}% complete)` : ''}`;
  
  const style = state === 'learning' && progress !== undefined
    ? { '--aec-progress': `${progress}%` } as React.CSSProperties
    : undefined;
  
  return (
    <div
      className={`aec-indicator aec-indicator--${state} aec-indicator--${size} aec-indicator--rate-${creditRate}`}
      role="status"
      aria-label={ariaLabel}
      style={style}
    >
      <div className="aec-indicator__ring"></div>
      <div className="aec-indicator__fill"></div>
    </div>
  );
}
```

**Test All States:**

```tsx
// src/stories/AECIndicator.stories.tsx
export default {
  title: 'Components/AECIndicator',
  component: AECIndicator,
};

export const Processing = () => <AECIndicator state="processing" />;
export const Analyzing = () => <AECIndicator state="analyzing" />;
export const Generating = () => <AECIndicator state="generating" />;
export const Learning = () => <AECIndicator state="learning" progress={65} />;
export const Complete = () => <AECIndicator state="complete" />;
export const Idle = () => <AECIndicator state="idle" />;
export const Error = () => <AECIndicator state="error" />;
```

**Validation:**
- [ ] All 7 AEC states render correctly
- [ ] Animations functional
- [ ] Reduced motion fallback working
- [ ] ARIA labels present
- [ ] Colors match canonical values

---

### Step 2.4: Integrate Agent Avatars

**Create Agent Avatar Component:**

```tsx
// src/components/AgentAvatar.tsx
import { AECIndicator } from './AECIndicator';

interface AgentAvatarProps {
  agentId: 'javari' | 'amara' | 'agent-03' | 'agent-04';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  aecState?: 'processing' | 'analyzing' | 'generating' | 'learning' | 'complete' | 'idle' | 'error';
  imageSrc?: string;
}

export function AgentAvatar({
  agentId,
  size = 'md',
  aecState = 'idle',
  imageSrc
}: AgentAvatarProps) {
  const agentColor = `var(--color-agent-01-${agentId})`;
  
  return (
    <div 
      className={`agent-avatar agent-avatar--${size}`}
      style={{ borderColor: agentColor }}
    >
      <img 
        src={imageSrc || `/avatars/${agentId}.svg`} 
        alt={`${agentId} agent`}
        className="agent-avatar__image"
      />
      <div className="agent-avatar__aec">
        <AECIndicator 
          state={aecState} 
          size={size === 'lg' ? 'md' : 'sm'} 
        />
      </div>
    </div>
  );
}
```

**Styling:**

```css
/* src/components/AgentAvatar.css */
.agent-avatar {
  position: relative;
  border-radius: 50%;
  border: var(--avatar-border-width) solid;
  background-color: var(--avatar-bg);
  overflow: hidden;
}

.agent-avatar--sm {
  width: var(--avatar-size-sm);
  height: var(--avatar-size-sm);
}

.agent-avatar--md {
  width: var(--avatar-size-md);
  height: var(--avatar-size-md);
}

.agent-avatar--lg {
  width: var(--avatar-size-lg);
  height: var(--avatar-size-lg);
}

.agent-avatar__image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.agent-avatar__aec {
  position: absolute;
  bottom: -2px;
  right: -2px;
  width: 50%;
  height: 50%;
  border: 2px solid var(--bg-primary);
  border-radius: 50%;
}
```

**Validation:**
- [ ] Agent color signatures display correctly
- [ ] AEC overlays position properly
- [ ] All size variants work
- [ ] Border colors match agent signatures

---

## Phase 3: Accessibility Testing (Week 4)

### Step 3.1: Contrast Validation

**Automated Testing:**

```javascript
// tests/accessibility/contrast.test.ts
import { getContrastRatio } from '@/utils/accessibility';
import colors from '@/tokens/colors';

describe('Color Contrast Compliance', () => {
  test('AI-state colors meet WCAG AA on Navy', () => {
    expect(getContrastRatio(colors.AIStateColors.crimson, colors.StructuralColors.navy))
      .toBeGreaterThanOrEqual(4.5);
  });
  
  test('Functional colors meet WCAG AA on White', () => {
    expect(getContrastRatio(colors.FunctionalColors.success.primary, '#FFFFFF'))
      .toBeGreaterThanOrEqual(4.5);
  });
});
```

**Manual Testing:**

Use browser dev tools or online tools:
- https://webaim.org/resources/contrastchecker/
- https://color.review/

**Validation:**
- [ ] All text colors meet 4.5:1 minimum
- [ ] Large text meets 3:1 minimum
- [ ] UI components meet 3:1 minimum
- [ ] Focus indicators meet 3:1 minimum

---

### Step 3.2: Focus Indicator Testing

**Test Checklist:**

- [ ] Tab through entire interface
- [ ] All interactive elements show focus
- [ ] Focus indicators visible in light mode
- [ ] Focus indicators visible in dark mode
- [ ] Focus outline 2px minimum
- [ ] Focus offset 2px minimum
- [ ] No `outline: none` without replacement

**Fix Missing Focus Indicators:**

```css
/* Add to any elements missing focus */
:focus-visible {
  outline: 2px solid var(--color-focus-indicator);
  outline-offset: 2px;
}
```

---

### Step 3.3: Reduced Motion Testing

**Test Procedure:**

1. Enable reduced motion in OS settings:
   - **macOS:** System Preferences → Accessibility → Display → Reduce motion
   - **Windows:** Settings → Ease of Access → Display → Show animations
   - **iOS:** Settings → Accessibility → Motion → Reduce Motion

2. Verify all animations disabled:
   - [ ] AEC pulsing stops
   - [ ] AEC rotation stops
   - [ ] AEC shimmer stops
   - [ ] Static colors display instead
   - [ ] Transitions immediate

**Validation:**
- [ ] All motion stops when `prefers-reduced-motion: reduce` active
- [ ] Static color fills show for all AEC states
- [ ] No jarring transitions
- [ ] Functionality preserved

---

### Step 3.4: Screen Reader Testing

**Test with:**
- **macOS:** VoiceOver (Cmd + F5)
- **Windows:** NVDA or JAWS
- **Mobile:** TalkBack (Android) or VoiceOver (iOS)

**Checklist:**

- [ ] Button purposes announced
- [ ] AEC states announced ("Agent is processing")
- [ ] Form labels associated with inputs
- [ ] Error messages read aloud
- [ ] Focus order logical
- [ ] Landmark regions identified

---

### Step 3.5: Color-Blind Simulation

**Tools:**
- Browser extensions: Chrome "Colorblind" extension
- Design tools: Figma "Stark" plugin
- Online: https://www.color-blindness.com/coblis-color-blindness-simulator/

**Test Types:**
- Deuteranopia (red-green) - Most common
- Protanopia (red-green)
- Tritanopia (blue-yellow)

**Validation:**
- [ ] Success vs Error distinguishable (not relying on green/red alone)
- [ ] Charts use patterns + colors
- [ ] Status indicators include icons
- [ ] No information conveyed by color alone

---

## Phase 4: Documentation & Training (Week 5)

### Step 4.1: Generate Internal Documentation

**Create Design System Site:**

Use Storybook or custom documentation site:

```bash
# Install Storybook
npx storybook init

# Add color documentation
# stories/Colors.stories.mdx
```

**Include:**
- Live color swatches
- Usage examples
- Code snippets
- Dos and don'ts
- Contrast ratios

**Validation:**
- [ ] All color tokens documented
- [ ] Usage examples clear
- [ ] Code copy-paste functional

---

### Step 4.2: Train Design Team

**Workshop Agenda (2 hours):**

1. **Overview (15 min)**
   - Why new color system
   - Canonical colors from Brand Canon

2. **Figma Integration (30 min)**
   - Import color styles from CSV
   - Lock canonical colors
   - Create component variants

3. **Usage Rules (30 min)**
   - AI-state vs functional disambiguation
   - When to use each color family
   - Accessibility requirements

4. **Hands-On Practice (30 min)**
   - Design mockup using new tokens
   - Validate contrast
   - Export for engineering

5. **Q&A (15 min)**

**Validation:**
- [ ] Designers can import tokens to Figma
- [ ] Designers understand usage rules
- [ ] Designers can validate accessibility

---

### Step 4.3: Train Engineering Team

**Workshop Agenda (2 hours):**

1. **Token System (30 min)**
   - CSS/SCSS/TS token structure
   - Semantic naming conventions
   - Dark mode implementation

2. **Component Integration (45 min)**
   - Migrating existing components
   - Building new components
   - AEC indicator usage
   - Agent avatar integration

3. **Testing Requirements (30 min)**
   - Contrast validation
   - Accessibility testing
   - Visual regression

4. **Hands-On Practice (15 min)**
   - Migrate sample component
   - Test in light/dark modes

**Validation:**
- [ ] Engineers understand token usage
- [ ] Engineers can migrate components
- [ ] Engineers know testing requirements

---

## Phase 5: Production Deployment (Week 6)

### Step 5.1: Final Pre-Deployment Checks

**Checklist:**

- [ ] All components migrated
- [ ] All tests passing
- [ ] Visual regression tests green
- [ ] Accessibility audit complete
- [ ] Documentation published
- [ ] Team training complete
- [ ] Staging environment validated
- [ ] Performance benchmarks acceptable

---

### Step 5.2: Staged Rollout Plan

**Option A: Feature Flag (Recommended)**

```typescript
// Feature flag
const useNewColorSystem = getFeatureFlag('color-system-r2');

// Conditional class
<html className={useNewColorSystem ? 'color-system-r2' : 'legacy'}>
```

**Rollout Schedule:**

- **Week 1:** 10% of users
- **Week 2:** 25% of users
- **Week 3:** 50% of users
- **Week 4:** 100% of users (if no issues)

**Option B: All-at-once (Higher Risk)**

Deploy to production in single release.

**Validation:**
- [ ] Monitoring dashboards configured
- [ ] Error tracking active
- [ ] Rollback plan documented
- [ ] On-call rotation scheduled

---

### Step 5.3: Monitoring & Validation

**Monitor:**

- Error rates (expect no increase)
- Page load times (expect no degradation)
- User feedback/support tickets
- Accessibility complaints

**Metrics:**

```typescript
// Track color system adoption
analytics.track('color_system_version', {
  version: 'R.2.0',
  theme: document.documentElement.getAttribute('data-theme')
});
```

**Validation:**
- [ ] No error rate increase
- [ ] No performance degradation
- [ ] Positive user feedback
- [ ] No accessibility regressions

---

### Step 5.4: Post-Deployment Cleanup

**After successful rollout:**

- [ ] Remove legacy color code
- [ ] Delete unused CSS variables
- [ ] Remove feature flags
- [ ] Archive old documentation
- [ ] Update design system version
- [ ] Celebrate! 🎉

---

## 🆘 Troubleshooting

### Issue: Colors not updating in dark mode

**Solution:** Check `data-theme` attribute on `<html>`:

```javascript
console.log(document.documentElement.getAttribute('data-theme'));
// Should be 'light' or 'dark'
```

### Issue: AEC animations not working

**Solution:** Check for `prefers-reduced-motion`:

```javascript
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
console.log('Reduced motion:', prefersReducedMotion);
```

### Issue: TypeScript autocomplete not working

**Solution:** Restart TypeScript server or rebuild types:

```bash
npm run type-check
```

### Issue: Contrast failures

**Solution:** Reference `verification/contrast-matrix.md` for compliant pairings.

---

## 📞 Support Contacts

**Technical Issues:** engineering@craudiovizai.com  
**Design Questions:** design@craudiovizai.com  
**Accessibility:** accessibility@craudiovizai.com

---

**IMPLEMENTATION GUIDE COMPLETE**
