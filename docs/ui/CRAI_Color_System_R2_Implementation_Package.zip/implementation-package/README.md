# CRAI Color System R.2.0 Implementation Package
**Harmonized Canon Edition**

## 📦 Package Contents

This implementation package contains all engineering assets, documentation, and verification materials needed to deploy the CRAI Color System R.2.0 across the platform.

---

## 📁 Directory Structure

```
implementation-package/
├── tokens/
│   ├── colors.css              # CSS Custom Properties (Variables)
│   ├── colors.scss             # SCSS Variables & Maps
│   ├── colors.ts               # TypeScript Token Definitions
│   └── figma-color-export.csv  # Figma Color Styles Export
├── components/
│   ├── buttons.md              # Button Component Integration Guide
│   ├── aec-indicators.md       # AEC Indicator Specifications
│   ├── inputs.md               # Form Input Components
│   ├── navigation.md           # Navigation Components
│   ├── agent-avatars.md        # Agent Avatar Components
│   ├── status-badges.md        # Status Badge Components
│   ├── cards.md                # Card Components
│   ├── tables.md               # Table Components
│   └── dashboards.md           # Dashboard Surfaces
├── animations/
│   ├── aec-animations.css      # AEC Animation Specifications
│   └── motion-reduced.css      # Reduced Motion Fallbacks
├── verification/
│   ├── color-swatches.md       # Visual Verification Sheet
│   ├── contrast-matrix.md      # WCAG Contrast Testing
│   └── swatches/               # PNG Swatch Images
│       ├── ai-state-colors.png
│       ├── structural-colors.png
│       ├── functional-colors.png
│       └── data-viz-colors.png
├── README.md                   # This file
└── IMPLEMENTATION_GUIDE.md     # Step-by-step deployment guide
```

---

## 🎯 Quick Start

### 1. Install Color Tokens

**CSS:**
```html
<link rel="stylesheet" href="tokens/colors.css">
```

**SCSS:**
```scss
@import 'tokens/colors';

.button-primary {
  background-color: structural('navy');
  color: neutral('0');
}
```

**TypeScript:**
```typescript
import { getAIStateColor, getAECColor } from '@/tokens/colors';

const processingColor = getAECColor('processing'); // '#DC143C'
```

---

## 🔑 Key Principles

### 1. Canonical Colors are IMMUTABLE

The following colors are defined in **CRAV_DYNAMIC_MATERIAL_BRAND_CANON_v1** and cannot be modified:

- **AI-State Colors:** Crimson, Cyan, Violet, Amber, Emerald, Graphite
- **Structural Colors:** Navy, Deep Navy

Any changes to these colors require Brand Canon revision.

### 2. Semantic Token Usage

Always use semantic tokens, never hardcoded HEX values:

```css
/* ✓ CORRECT */
color: var(--aec-processing);
background: var(--bg-primary);

/* ✗ PROHIBITED */
color: #DC143C;
background: #FFFFFF;
```

### 3. AI-State vs Functional Color Disambiguation

- **AI-State Colors:** Use for AEC indicators, agent states, AI operations
- **Functional Colors:** Use for form validation, system alerts, user feedback

**Examples:**
- AI operation completed successfully → Emerald (AI-state)
- File uploaded successfully → Success (functional)
- AI model degraded → Amber (AI-state) + Warning (functional alert)
- Network error → Error (functional)

---

## 🎨 Color Categories

### AI-State Colors (Immutable)
```
Crimson  #DC143C  Processing / Active Computation
Cyan     #00CED1  Analysis / Data Synthesis
Violet   #8A2BE2  Creative Generation / Ideation
Amber    #FFBF00  Learning / Knowledge Acquisition
Emerald  #50C878  Success / Completion
Graphite #4A4A4A  Neutral / Baseline
```

### Structural Colors (Immutable)
```
Navy       #001F3F  Primary structural foundation
Deep Navy  #000D1A  Maximum depth / Dark mode backgrounds
```

### Functional Colors
```
Success  #16A34A  User/system success states
Warning  #D97706  Caution / degraded performance
Error    #DC2626  Failed operations / critical alerts
Info     #0284C7  System notifications / help content
```

### Economic Colors
```
Credit   #0891B2  Credit balance / available funds
Debit    #DC2626  Credit expenditure / charges
Fiat     #15803D  Real currency (USD/EUR/GBP)
Neutral  #525252  Zero-cost / free tier
```

---

## ♿ Accessibility Compliance

All colors meet **WCAG 2.2 Level AA** standards:

- Minimum contrast ratio: **4.5:1** for normal text
- Minimum contrast ratio: **3:1** for large text and UI components
- Non-color redundancy: Icons, labels, and patterns accompany all color-coded information
- Reduced motion support: All animations disable for `prefers-reduced-motion: reduce`

### Contrast Quick Reference

| Color | vs White | vs Navy | Usage Notes |
|-------|----------|---------|-------------|
| Crimson | 5.04:1 ✓ | 5.89:1 ✓ | Text OK |
| Cyan | 3.26:1 ✗ | 7.34:1 ✓ | Large text only on white |
| Violet | 5.65:1 ✓ | 4.23:1 ✗ | Text OK on white |
| Amber | 2.36:1 ✗ | 10.12:1 ✓ | Graphics only on white |
| Emerald | 3.52:1 ✗ | 6.78:1 ✓ | Large text only on white |
| Graphite | 12.63:1 ✓ | 1.89:1 ✗ | Text OK on white |

---

## 🚀 Implementation Checklist

### Phase 1: Token Infrastructure
- [ ] Import color token files (CSS/SCSS/TS)
- [ ] Configure theme switching (`[data-theme="dark"]`)
- [ ] Set up build validation (no hardcoded HEX values)
- [ ] Generate TypeScript types for autocomplete

### Phase 2: Component Integration
- [ ] Audit existing components for hardcoded colors
- [ ] Implement AEC indicator component
- [ ] Create agent avatar components
- [ ] Build status badge components
- [ ] Update button variants (primary, secondary, danger)
- [ ] Integrate form input components
- [ ] Update navigation chrome
- [ ] Implement card and table components
- [ ] Build dashboard surfaces

### Phase 3: Accessibility Testing
- [ ] Contrast validation for all color pairings
- [ ] Focus indicator visibility testing
- [ ] Reduced motion fallback verification
- [ ] Screen reader compatibility testing
- [ ] Color-blind simulation testing (deuteranopia, protanopia)

### Phase 4: Documentation & Training
- [ ] Generate color palette documentation with live swatches
- [ ] Create usage examples for each AI-state color
- [ ] Document disambiguation rules (AI-state vs functional)
- [ ] Publish contrast ratio tables
- [ ] Train design and engineering teams

---

## 📋 Component Integration Guides

Detailed implementation specifications available for:

1. **Buttons** (`components/buttons.md`)
   - Primary, secondary, danger, ghost variants
   - AEC action buttons
   - Icon buttons
   - Loading states

2. **AEC Indicators** (`components/aec-indicators.md`)
   - All 7 AEC states with animations
   - Credit consumption visualization
   - Avatar integration
   - Multi-agent coordination

3. **Status Badges** (`components/status-badges.md`)
   - Success, warning, error, info variants
   - Sizing and positioning rules

4. **Agent Avatars** (`components/agent-avatars.md`)
   - Avatar color signatures
   - AEC overlay positioning
   - Multi-agent differentiation

5. **Forms & Inputs** (`components/inputs.md`)
   - Text inputs, textareas, selects
   - Validation states
   - Focus indicators

6. **Navigation** (`components/navigation.md`)
   - Primary navigation
   - Breadcrumbs
   - Tab navigation

7. **Cards & Tables** (`components/cards.md`, `components/tables.md`)
   - Card variants
   - Table styling
   - Data visualization integration

8. **Dashboards** (`components/dashboards.md`)
   - Dashboard surfaces
   - Widget styling
   - Metric displays

---

## 🎭 Animation Specifications

### AEC Animations (`animations/aec-animations.css`)

All AEC animations use **GPU-accelerated CSS transforms** for performance:

- **Processing (Crimson):** Pulsing opacity (0.8s cycle)
- **Analyzing (Cyan):** Rotating particles (2s rotation)
- **Generating (Violet):** Shimmer effect (1.5s sweep)
- **Learning (Amber):** Progressive fill (based on progress %)
- **Complete (Emerald):** Static solid or single check pulse
- **Idle (Graphite):** Static at 40% opacity
- **Error (Error Red):** Static with alert icon

### Reduced Motion Fallbacks

All animations automatically disable for users with motion sensitivity:

```css
@media (prefers-reduced-motion: reduce) {
  .aec-indicator * {
    animation: none !important;
    transition: none !important;
  }
}
```

---

## 🖼️ Figma Integration

### Import Color Styles

1. Open `tokens/figma-color-export.csv`
2. In Figma: **Plugins → Import Styles**
3. Map columns:
   - Token Name → Style Name
   - HEX Value → Color Value
   - Category → Group
4. Lock canonical AI-state color styles (prevent accidental modification)
5. Create component variants for light/dark modes

### Validation Plugins

Use these Figma plugins for accessibility validation:
- **Stark:** Contrast checking, colorblind simulation
- **A11y - Color Contrast Checker:** WCAG compliance verification

---

## 🧪 Testing & Validation

### Visual Regression Testing

Use Percy, Chromatic, or BackstopJS to test:
- Light/dark mode variants
- AEC animation states
- Agent avatar color boundaries
- Button hover/focus states

### Accessibility Testing

```javascript
// Example using jest-axe
import { axe, toHaveNoViolations } from 'jest-axe';

expect.extend(toHaveNoViolations);

test('AEC indicator meets WCAG AA', async () => {
  const { container } = render(<AECIndicator state="processing" />);
  const results = await axe(container);
  expect(results).toHaveNoViolations();
});
```

### Contrast Validation

All color pairings pre-verified in `verification/contrast-matrix.md`

---

## 📚 Additional Resources

- **Brand Canon v1:** Source authority for canonical colors
- **Visual Strategy R.1.1:** Design principles and visual language
- **Typography R.1.0:** Typography system specification
- **WCAG 2.2 Guidelines:** https://www.w3.org/WAI/WCAG22/quickref/

---

## 🆘 Support & Questions

### Common Issues

**Q: Why can't I use Emerald for success messages?**  
A: Emerald is an AI-state color representing AI operation completion. Use functional Success (#16A34A) for non-AI success states.

**Q: Can I lighten Crimson for a softer look?**  
A: No. AI-state colors are canonical and immutable. Use opacity reduction only for inactive agent states (70% active background, 40% idle).

**Q: Why is my AEC animation not working?**  
A: Check for `prefers-reduced-motion: reduce` setting. Animations intentionally disable for accessibility.

**Q: Can I add a new brand accent color?**  
A: No. The color system is closed to prevent palette proliferation. Use existing semantic tokens.

---

## 📝 Version History

**R.2.0 (2026-01-19) - Harmonized Canon Edition**
- Integrated canonical AI-state colors from Brand Canon v1
- Added Navy and Deep Navy structural colors
- Harmonized functional colors with AI-state palette
- Complete AEC animation specifications
- Full component integration guides
- WCAG 2.2 AA compliance verification

**R.1.0 (Previous)**
- Initial enterprise neutral palette
- Basic functional colors
- Superseded by R.2.0

---

## ⚖️ License & Authority

**Authority:** CRAV_DYNAMIC_MATERIAL_BRAND_CANON_v1  
**Status:** Implementation-Ready Canonical Specification  
**Canonical Colors:** IMMUTABLE without Brand Canon revision  
**Copyright:** © 2026 CR AudioViz AI, LLC

---

**END OF README**
